

def decrypt(ciphertext, key):
    plaintext = ""
    key_length = len(key)
    for i in range(len(ciphertext)):
        char = ciphertext[i]
        if char.isalpha():
            key_char = key[i % key_length]
            key_index = ord(key_char) - 97
            char_index = ord(char) - 97
            new_index = (char_index - key_index) % 26
            plaintext += chr(new_index + 97)
        else:
            plaintext += char
    return plaintext



