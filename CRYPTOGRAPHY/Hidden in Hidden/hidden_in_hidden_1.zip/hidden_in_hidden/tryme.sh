#!/bin/sh

echo "Hello, welcome to {hidden_behind_hidden} challenge\n"

echo "Enter two numbers"
read a
read b

# Input type of operation
# 47imot347tt{l1wi3y_7v0f_g0i}
echo "Enter Choice :"
echo "1. Addition"
echo "2. Subtraction"
echo "3. Multiplication"
echo "4. Division"
read ch

# Switch Case to perform
# calculator operations
case $ch in
  1)res=`echo $a + $b | bc`
    echo ''
    echo 'key'
  ;;
  2)res=`echo $a - $b | bc`
    echo ''
    echo 'i'
  ;;
  3)res=`echo $a \* $b | bc`
    echo ''
    echo 'love'
  ;;
  4)res=`echo "scale=2; $a / $b" | bc`
    echo ''
    echo 'ctf'
  ;;
esac
echo "Result : $res"

