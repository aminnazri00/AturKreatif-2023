
import base64
from cryptography.fernet import Fernet
import sys

usage_msg = "Usage: " + sys.argv[0] + " (-e/-d) [file]"
help_msg = usage_msg + "\n" +\
    "Example:\n" +\
        " To decrypt a file, put any arguments in the commad as below:\n" +\
            "$ python3 " + sys.argv[0] +" -e test.txt"

if len(sys.argv) < 2 or len(sys.argv) > 4:
    print(usage_msg)
    sys.exit(1)



if sys.argv[1] == "-e":
    if len(sys.argv) < 4:
        key = input("Please enter the key:")
        
    else:
        key = sys.argv[3]
        
    
    try:
        f = Fernet(key)
        with open(sys.argv[2], "rb") as file:
            data = file.read()
            encode_data = base64.b64encode(data)
            data = f.encrypt(encode_data)
	    print("...")
    except:
        print("ERROR! Please try again")



elif sys.argv[1] == "-d":
    
    if len(sys.argv) < 4:
        key = input("Please enter the key:")
    
    else:
        key = sys.argv[3]
    
    
    try:
        f = Fernet(key)
        with open(sys.argv[2], "rb") as file:
            data = file.read()
            data = f.decrypt(data)
            sys.stdout.buffer.write("...")
    except:
        print("ERROR! Please try again")


    
elif sys.argv[1] == "-h":
    print(help_msg)
    
else:
    print("Unrecognized arguments: " + sys.argv[1])
    
    

